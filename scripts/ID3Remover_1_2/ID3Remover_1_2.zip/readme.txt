What is ID3Remover
------------------

I had a bunch of mp3-files with id3-tags on them. But I don't use
the id3 tag to anything. I use filenames and folders to "tag" my
mp3-files. So I went out and searched for an id3-tag remover but
couldn't find any. But I did find several id3-tagger.

Anyway, feel free to use this software. You drag the files from explorer
onto ID3Remover and press remove. If it finds an id3 tag it removes it,
I couldn't have done it easier. You can even drop entire folders and it
scans for mp3 files in all subdirectories.

Changelog for version 1.2
-------------------------
 o Added option to only remove ID3v1 or ID3v2 tags

Changelog for version 1.1
-------------------------
 o Added support for ID3 v.2 tags.

Installation 
------------

The installation is quite simple. Just copy the files into a directory
and run ID3Remover from that dir. ID3Remover doesn't install anything in your
windows/system directory and it doesn't mess with your registry.


Contact Information
-------------------

For more information visit the ID3Remover homepage
http://www.marre.org/id3remover/

Markus Eriksson (id3remover@marre.org)
